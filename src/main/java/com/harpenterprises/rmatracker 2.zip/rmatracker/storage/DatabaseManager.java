package com.harpenterprises.rmatracker.storage;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public final class DatabaseManager {

    private static final String APPLICATION_FOLDER_NAME = "RMA Tracker";
    private static final String DATABASE_FOLDER_NAME = "data";
    private static final String DATABASE_FILE_NAME = "rma-tracker.db";

    /*
     * Store writable application data in the current user's macOS
     * Application Support folder instead of using a relative "data" folder.
     *
     * Example:
     * /Users/YourName/Library/Application Support/RMA Tracker/data
     */
    private static final File APPLICATION_FOLDER = new File(
            new File(
                    new File(System.getProperty("user.home"), "Library"),
                    "Application Support"
            ),
            APPLICATION_FOLDER_NAME
    );

    private static final File DATABASE_FOLDER = new File(
            APPLICATION_FOLDER,
            DATABASE_FOLDER_NAME
    );

    private static final File DATABASE_FILE = new File(
            DATABASE_FOLDER,
            DATABASE_FILE_NAME
    );

    private static final String DATABASE_URL =
            "jdbc:sqlite:" + DATABASE_FILE.getAbsolutePath();

    private DatabaseManager() {
        // Prevent this utility class from being instantiated.
    }

    /**
     * Returns the location of the active SQLite database file.
     */
    public static File getDatabaseFile() {
        createDatabaseFolder();
        return DATABASE_FILE;
    }

    /**
     * Returns the main writable application folder.
     *
     * BackupService can use this method to store backups under:
     * ~/Library/Application Support/RMA Tracker/backups
     */
    public static File getApplicationFolder() {
        createApplicationFolder();
        return APPLICATION_FOLDER;
    }

    public static Connection getConnection() throws SQLException {
        createDatabaseFolder();

        Connection connection =
                DriverManager.getConnection(DATABASE_URL);

        try (Statement statement = connection.createStatement()) {
            statement.execute("PRAGMA foreign_keys = ON");
        }

        return connection;
    }

    public static void initializeDatabase() {
        createDatabaseFolder();

        try (Connection connection = getConnection();
             Statement statement = connection.createStatement()) {

            statement.execute("""
                    CREATE TABLE IF NOT EXISTS rmas (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        rma_number TEXT NOT NULL UNIQUE,
                        date_sent TEXT,
                        date_received TEXT,
                        status TEXT NOT NULL,
                        outgoing_tracking_number TEXT,
                        return_tracking_number TEXT,
                        notes TEXT,
                        created_at TEXT NOT NULL
                            DEFAULT CURRENT_TIMESTAMP,
                        updated_at TEXT NOT NULL
                            DEFAULT CURRENT_TIMESTAMP
                    )
                    """);

            statement.execute("""
                    CREATE TABLE IF NOT EXISTS repair_items (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        rma_id INTEGER NOT NULL,
                        county TEXT NOT NULL,
                        machine_type TEXT NOT NULL,
                        serial_number TEXT,
                        version TEXT,
                        problem_description TEXT,
                        repair_description TEXT,
                        received INTEGER NOT NULL DEFAULT 0,
                        FOREIGN KEY (rma_id)
                            REFERENCES rmas(id)
                            ON DELETE CASCADE
                    )
                    """);

            statement.execute("""
                    CREATE TABLE IF NOT EXISTS shipping_information (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        rma_id INTEGER NOT NULL,
                        carrier TEXT NOT NULL,
                        tracking_number TEXT NOT NULL,
                        shipping_direction TEXT NOT NULL,
                        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (rma_id)
                            REFERENCES rmas(id)
                            ON DELETE CASCADE
                    )
                    """);

            statement.execute("""
                    CREATE TABLE IF NOT EXISTS status_history (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        rma_id INTEGER NOT NULL,
                        old_status TEXT,
                        new_status TEXT NOT NULL,
                        changed_at TEXT NOT NULL,
                        FOREIGN KEY (rma_id)
                            REFERENCES rmas(id)
                            ON DELETE CASCADE
                    )
                    """);

            /*
             * Give RMAs created before status history existed
             * one initial history entry using their current status.
             */
            statement.execute("""
                    INSERT INTO status_history (
                        rma_id,
                        old_status,
                        new_status,
                        changed_at
                    )
                    SELECT
                        r.id,
                        NULL,
                        r.status,
                        COALESCE(r.created_at, CURRENT_TIMESTAMP)
                    FROM rmas r
                    WHERE NOT EXISTS (
                        SELECT 1
                        FROM status_history h
                        WHERE h.rma_id = r.id
                    )
                    """);

            /*
             * Handle databases created before these columns were added.
             */
            addColumnIfMissing(
                    connection,
                    "repair_items",
                    "version",
                    "TEXT"
            );

            addColumnIfMissing(
                    connection,
                    "repair_items",
                    "repair_description",
                    "TEXT"
            );

            addColumnIfMissing(
                    connection,
                    "repair_items",
                    "received",
                    "INTEGER NOT NULL DEFAULT 0"
            );

            statement.execute("""
                    CREATE INDEX IF NOT EXISTS idx_rmas_rma_number
                    ON rmas(rma_number)
                    """);

            statement.execute("""
                    CREATE INDEX IF NOT EXISTS idx_items_rma_id
                    ON repair_items(rma_id)
                    """);

            statement.execute("""
                    CREATE INDEX IF NOT EXISTS idx_items_county
                    ON repair_items(county)
                    """);

            statement.execute("""
                    CREATE INDEX IF NOT EXISTS idx_items_serial
                    ON repair_items(serial_number)
                    """);

            statement.execute("""
                    CREATE INDEX IF NOT EXISTS idx_shipping_rma_id
                    ON shipping_information(rma_id)
                    """);

            statement.execute("""
                    CREATE INDEX IF NOT EXISTS idx_shipping_tracking
                    ON shipping_information(tracking_number)
                    """);

            statement.execute("""
                    CREATE INDEX IF NOT EXISTS idx_history_rma_id
                    ON status_history(rma_id)
                    """);

            statement.execute("""
                    CREATE INDEX IF NOT EXISTS idx_history_changed_at
                    ON status_history(changed_at)
                    """);

            System.out.println(
                    "SQLite database initialized successfully."
            );

            System.out.println(
                    "Database location: "
                            + DATABASE_FILE.getAbsolutePath()
            );

        } catch (SQLException exception) {
            throw new IllegalStateException(
                    "Could not initialize the SQLite database.",
                    exception
            );
        }
    }

    private static void addColumnIfMissing(
            Connection connection,
            String tableName,
            String columnName,
            String columnDefinition
    ) throws SQLException {

        if (columnExists(connection, tableName, columnName)) {
            return;
        }

        String sql =
                "ALTER TABLE "
                        + tableName
                        + " ADD COLUMN "
                        + columnName
                        + " "
                        + columnDefinition;

        try (Statement statement = connection.createStatement()) {
            statement.execute(sql);
        }

        System.out.println(
                "Added database column: "
                        + tableName
                        + "."
                        + columnName
        );
    }

    private static boolean columnExists(
            Connection connection,
            String tableName,
            String columnName
    ) throws SQLException {

        String sql = "PRAGMA table_info(" + tableName + ")";

        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sql)) {

            while (resultSet.next()) {
                String existingColumn =
                        resultSet.getString("name");

                if (columnName.equalsIgnoreCase(existingColumn)) {
                    return true;
                }
            }
        }

        return false;
    }

    private static void createApplicationFolder() {
        if (!APPLICATION_FOLDER.exists()
                && !APPLICATION_FOLDER.mkdirs()) {

            throw new IllegalStateException(
                    "Could not create the application folder: "
                            + APPLICATION_FOLDER.getAbsolutePath()
            );
        }
    }

    private static void createDatabaseFolder() {
        createApplicationFolder();

        if (!DATABASE_FOLDER.exists()
                && !DATABASE_FOLDER.mkdirs()) {

            throw new IllegalStateException(
                    "Could not create the database folder: "
                            + DATABASE_FOLDER.getAbsolutePath()
            );
        }
    }
}
